/* 

Efaz's Roblox Logo Changer
By: EfazDev
Page: https://www.efaz.dev/roblox-logo-changer

inject.js:
    - Content script that edits the Roblox logo on the website.

*/

(function () {
    const storage = chrome.storage.local;
    const storage_key = "dev.efaz.roblox_logo_changer";
    function getChromeURL(resource) {
        try {
            // This is for Efaz's Roblox Extension support
            if (chrome.runtime.getManifest()["homepage_url"] == "https://www.efaz.dev/roblox-extension") {
                // This is run under bundled extension [{extension_name}/{resource}]
                return chrome.runtime.getURL("dev.efaz.roblox_logo_changer" + "/" + resource);
            } else {
                return chrome.runtime.getURL(resource);
            }
        } catch (_) {
            // This is run under mini extension [{resource}]
            return chrome.runtime.getURL(resource);
        }
    }
    async function loopThroughArrayAsync(array, callback) {
        if (Array.isArray(array)) {
            for (let a = 0; a < array.length; a++) {
                await callback(a, array[a]);
            }
        } else if (array && typeof array === "object") {
            for (const a of Object.keys(array)) {
                await callback(a, array[a]);
            }
        }
    }
    function getTran(id) {
        if (!(chrome.i18n.getMessage(storage_key.replaceAll(".", "_") + "_" + id) == "")) {
            return chrome.i18n.getMessage(storage_key.replaceAll(".", "_") + "_" + id);
        } else if (!(chrome.i18n.getMessage(id.replaceAll(".", "_")) == "")) {
            return chrome.i18n.getMessage(id.replaceAll(".", "_"));
        }
    }
    async function getSettings(storage_key, callback) {
        return await fetch(getChromeURL("settings.json")).then((res) => {
            if (res.ok) { return res.json(); }
        }).then(async (jso) => {
            if (jso) {
                let te = await storage.get(storage_key);
                let user_settings = {};
                if (te && te[storage_key]) {
                    user_settings = te;
                } else if (jso["old_name"]) {
                    let old = await storage.get(jso["old_name"]);
                    if (old) {
                        user_settings = old;
                        user_settings = { [storage_key]: user_settings[jso["old_name"]] };
                    }
                }
                if (!(user_settings[storage_key])) { user_settings[storage_key] = {}; }
                await loopThroughArrayAsync(jso["settings"], async (i, v) => {
                    if (typeof (user_settings[storage_key][i]) == "undefined") {
                        if (!(typeof (v["default"]) == "undefined")) {
                            if (!(getTran(i + "_default") == null)) {
                                user_settings[storage_key][i] = (getTran(i + "_default"));
                            } else {
                                user_settings[storage_key][i] = (v["default"]);
                            }
                        }
                    }
                });
                if (callback) { callback(user_settings); }
                return user_settings;
            }
        });
    }
    function timeout(func, ms) { setTimeout(func, ms); }

    try {
        getSettings(storage_key, function (items) {
            let settings = items[storage_key];
            if (settings["enabled"] == true) {
                let tab = window.location;
                if (tab.href) {
                    if (tab.hostname == "www.roblox.com") {
                        let amountOfSecondsBeforeLoop = (typeof (settings["loopSeconds"]) == "string" && Number(settings["loopSeconds"])) ? Number(settings["loopSeconds"]) : 100;
                        let rbx_icon_sector = ".app-icon-mac { background-image: url(rbx_icon) !important; } .app-icon-windows { background-image: url(rbx_icon) !important; } .app-icon-ios { background-image: url(rbx_icon) !important; } .app-icon-android { background-image: url(rbx_icon) !important; }";
                        let rbx_studio_icon_sector = ".studio-icon-mac { background-image: url(rbx_studio_icon) !important; } .studio-icon-windows { background-image: url(rbx_studio_icon) !important; }";
                        let rbx_top_left_icon_sector = ".icon-logo-r { background-image: url(top_left_icon) !important; } .game-social-links>.btn-secondary-lg .icon-social-media-roblox { background-position: 0 0px !important; background-image: url(top_left_icon); }";
                        let rbx_top_left_name_sector = ".icon-logo { background-image: url(top_left_name) !important; background-size: contain !important; background-position: center, center !important; } .icon-default-logo { background-image: url(top_left_name) !important; height:70px !important; }";
                        async function injectCSS() {
                            if (settings["projectedImage"] && settings["projectedImage"].startsWith("data")) {
                                let all_links = document.querySelectorAll("link");
                                await loopThroughArrayAsync(all_links, async (_, header) => {
                                    if (header.rel && header.rel == "icon" && header.href && !(header.href == settings["projectedImage"])) {
                                        header.setAttribute("href", settings["projectedImage"]);
                                    }
                                });
                                all_links = null;
                            }
                            if (settings["rbxIcon"] && settings["rbxIcon"].startsWith("data")) {
                                if (!(document.getElementById("rbx_icon"))) {
                                    let d = document.createElement("style");
                                    d.setAttribute("id", "rbx_icon");
                                    d.setAttribute("rel", "stylesheet");
                                    d.textContent = rbx_icon_sector.replaceAll("rbx_icon", settings["rbxIcon"]);
                                    document.head.append(d);
                                }
                            }
                            if (settings["rbxStudioIcon"] && settings["rbxStudioIcon"].startsWith("data")) {
                                if (!(document.getElementById("rbx_studio_icon"))) {
                                    let d = document.createElement("style");
                                    d.setAttribute("id", "rbx_studio_icon");
                                    d.setAttribute("rel", "stylesheet");
                                    d.textContent = rbx_studio_icon_sector.replaceAll("rbx_studio_icon", settings["rbxStudioIcon"]);
                                    document.head.append(d);
                                }
                            }
                            if (settings["topLeftLogo"] && settings["topLeftLogo"].startsWith("data")) {
                                if (!(document.getElementById("top_left_icon"))) {
                                    let d = document.createElement("style");
                                    d.setAttribute("id", "top_left_icon");
                                    d.setAttribute("rel", "stylesheet");
                                    d.textContent = rbx_top_left_icon_sector.replaceAll("top_left_icon", settings["topLeftLogo"]);
                                    document.head.append(d);
                                }
                            }
                            if (settings["topLeftName"] && settings["topLeftName"].startsWith("data")) {
                                if (!(document.getElementById("top_left_name"))) {
                                    let d = document.createElement("style");
                                    d.setAttribute("id", "top_left_name");
                                    d.setAttribute("rel", "stylesheet");
                                    d.textContent = rbx_top_left_name_sector.replaceAll("top_left_name", settings["topLeftName"]);
                                    document.head.append(d);
                                }
                            }
                            timeout(() => { injectCSS(); }, amountOfSecondsBeforeLoop);
                        }
                        injectCSS();
                    } else if (tab.hostname == "create.roblox.com") {
                        let amountOfSecondsBeforeLoop = (typeof (settings["loopSeconds"]) == "string" && Number(settings["loopSeconds"])) ? Number(settings["loopSeconds"]) : 100;
                        let path_str = "path[d='M3.38116 0L0 12.6188L12.6188 16L16 3.38116L3.38116 0ZM9.291 10.2363L5.76484 9.291L6.71013 5.76484L10.2377 6.71013L9.291 10.2363Z']"
                        async function injectCSS() {
                            if (settings["projectedImage2"] && settings["projectedImage2"].startsWith("data")) {
                                let all_svgs = document.querySelectorAll("a[href='/'] > span > svg > " + path_str + ", a[href='https://create.roblox.com/'] > span > svg > " + path_str);
                                await loopThroughArrayAsync(all_svgs, async (_, header) => {
                                    header.parentElement.outerHTML = '<img class="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium" width="30" height="30" src="' + settings["projectedImage2"] + '">';
                                });
                                all_svgs = null;
                                let creator_hub_icon = document.querySelectorAll(".web-blox-css-tss-nvpyzg-logo");
                                for (let i = 0; i < creator_hub_icon.length; i++) {
                                    let header = creator_hub_icon[i];
                                    if (header.tagName.toLowerCase() == "svg") {
                                        header.outerHTML = '<img class="' + header.classList.toString() + '" width="' + header.getAttribute("width") + '" height="' + header.getAttribute("height") + '" src="' + settings["projectedImage2"] + '">';
                                    }
                                }
                                creator_hub_icon = null;
                                let all_links = document.querySelectorAll("link");
                                await loopThroughArrayAsync(all_links, async (_, header) => {
                                    if (header.rel && header.rel == "icon" && header.href && !(header.href == settings["projectedImage2"])) {
                                        header.setAttribute("href", settings["projectedImage2"]);
                                    }
                                });
                                all_links = null;
                            }
                            if (settings["rbxStudioIcon"] && settings["rbxStudioIcon"].startsWith("data")) {
                                let all_icons = document.querySelectorAll(".web-blox-css-tss-1hgd7ws-studioIcon");
                                await loopThroughArrayAsync(all_icons, async (_, header) => {
                                    if (header.getAttribute("width") == "64") {
                                        header.setAttribute("src", settings["rbxStudioIcon"]);
                                    }
                                });
                                all_icons = null;
                            }
                            timeout(() => { injectCSS(); }, amountOfSecondsBeforeLoop);
                        }
                        injectCSS();
                    } else if (tab.hostname == "devforum.roblox.com") {
                        let amountOfSecondsBeforeLoop = (typeof (settings["loopSeconds"]) == "string" && Number(settings["loopSeconds"])) ? Number(settings["loopSeconds"]) : 100;
                        async function injectCSS() {
                            if (settings["projectedImage3"] && settings["projectedImage3"].startsWith("data")) {
                                let all_links = document.querySelectorAll("link");
                                await loopThroughArrayAsync(all_links, async (_, header) => {
                                    if (header.rel && header.rel == "icon" && header.href && !(header.href == settings["projectedImage3"])) {
                                        header.setAttribute("href", settings["projectedImage3"]);
                                    }
                                });
                                all_links = null;
                            }
                            if (settings["projectedImage2"] && settings["projectedImage2"].startsWith("data")) {
                                let creator_hub_icon = document.querySelectorAll(".css-nvpyzg-logo");
                                for (let i = 0; i < creator_hub_icon.length; i++) {
                                    let header = creator_hub_icon[i];
                                    if (header.tagName.toLowerCase() == "svg") {
                                        header.outerHTML = '<img class="' + header.classList.toString() + '" width="' + header.getAttribute("width") + '" height="' + header.getAttribute("height") + '" src="' + settings["projectedImage2"] + '">';
                                    }
                                }
                                creator_hub_icon = null;
                            }
                            timeout(() => { injectCSS(); }, amountOfSecondsBeforeLoop);
                        }
                        injectCSS();
                    } else if (tab.hostname.endsWith(".roblox.com")) {
                        let amountOfSecondsBeforeLoop = (typeof (settings["loopSeconds"]) == "string" && Number(settings["loopSeconds"])) ? Number(settings["loopSeconds"]) : 100;
                        async function injectCSS() {
                            if (settings["projectedImage4"] && settings["projectedImage4"].startsWith("data")) {
                                let all_links = document.querySelectorAll("link");
                                await loopThroughArrayAsync(all_links, async (_, header) => {
                                    if (header.rel && header.rel == "icon" && header.href && !(header.href == settings["projectedImage4"])) {
                                        header.setAttribute("href", settings["projectedImage4"]);
                                    }
                                });
                                all_links = null;
                            }
                            if (settings["projectedImage2"] && settings["projectedImage2"].startsWith("data")) {
                                let creator_hub_icon = document.querySelectorAll(".css-nvpyzg-logo");
                                for (let i = 0; i < creator_hub_icon.length; i++) {
                                    let header = creator_hub_icon[i];
                                    if (header.tagName.toLowerCase() == "svg") {
                                        header.outerHTML = '<img class="' + header.getAttribute("class") + '" width="' + header.getAttribute("width") + '" height="' + header.getAttribute("height") + '" src="' + settings["projectedImage2"] + '">';
                                    }
                                }
                                creator_hub_icon = null;
                                let creator_hub_icon2 = document.querySelectorAll(".web-blox-css-mui-v3z1wi img");
                                for (let i = 0; i < creator_hub_icon2.length; i++) {
                                    let header = creator_hub_icon2[i];
                                    if (header.tagName.toLowerCase() == "img" && header.src.includes("roblox_icon")) {
                                        header.src = settings["projectedImage2"];
                                    }
                                }
                                creator_hub_icon2 = null;
                            }
                            timeout(() => { injectCSS(); }, amountOfSecondsBeforeLoop);
                        }
                        injectCSS();
                    }
                }
            }
        });
    } catch (err) {
        console.log("Failed to add font settings to this tab.");
    }
})();