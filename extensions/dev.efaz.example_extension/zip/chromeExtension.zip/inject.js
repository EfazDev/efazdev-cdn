/* 

Efaz's Example Extension
By: EfazDev
Website: https://www.efaz.dev/

inject.js:
    - Content script that does whatever the extension is tasked to do.

*/

(function () {
    const storage = chrome.storage.local;
    const storage_key = "dev.efaz.example_extension";
    function getChromeURL(resource) {
        try {
            // This is for Efaz's Roblox Extension support
            if (chrome.runtime.getManifest()["homepage_url"] == "https://www.efaz.dev/roblox-extension") {
                // This is run under bundled extension [{extension_name}/{resource}]
                return chrome.runtime.getURL("{extension_name_this_is_replace_when_building_bundle_with_folder_name_if_youre_wondering}" + "/" + resource);
            } else {
                return chrome.runtime.getURL(resource);
            }
        } catch (_) {
            // This is run under mini extension [{resource}]
            return chrome.runtime.getURL(resource);
        }
    }
    async function loopThroughArrayAsync(array, callback) {
        if (Array.isArray(array)) {
            for (let a = 0; a < array.length; a++) {
                await callback(a, array[a]);
            }
        } else if (array && typeof array === "object") {
            for (const a in array) {
                if (Object.hasOwn(array, a)) { await callback(a, array[a]); }
            }
        }
    }
    function loopThroughArray(array, callback) {
        if (Array.isArray(array)) {
            for (let a = 0; a < array.length; a++) {
                callback(a, array[a]);
            }
        } else if (array && typeof array === "object") {
            for (const a in array) {
                if (Object.hasOwn(array, a)) { callback(a, array[a]); }
            }
        }
    }
    function timeout(func, ms) { setTimeout(func, ms); }
    function getTran(id) {
        if (!(chrome.i18n.getMessage(storage_key.replaceAll(".", "_") + "_" + id) == "")) {
            return chrome.i18n.getMessage(storage_key.replaceAll(".", "_") + "_" + id);
        } else if (!(chrome.i18n.getMessage(id.replaceAll(".", "_")) == "")) {
            return chrome.i18n.getMessage(id.replaceAll(".", "_"));
        }
    }

    async function getSettings(storage_key, callback) {
        return await fetch(getChromeURL("settings.json")).then((res) => {
            if (res.ok) { return res.json(); }
        }).then(async (jso) => {
            if (jso) {
                let te = await storage.get(storage_key);
                let user_settings = {};
                if (te && te[storage_key]) {
                    user_settings = te;
                } else if (jso["old_name"]) {
                    let old = await storage.get(jso["old_name"]);
                    if (old) {
                        user_settings = old;
                        user_settings = { [storage_key]: user_settings[jso["old_name"]] };
                    }
                }
                if (!(user_settings[storage_key])) { user_settings[storage_key] = {}; }
                await loopThroughArrayAsync(jso["settings"], async (i, v) => {
                    if (typeof (user_settings[storage_key][i]) == "undefined") {
                        if (!(typeof (v["default"]) == "undefined")) {
                            if (!(getTran(i + "_default") == null)) {
                                user_settings[storage_key][i] = (getTran(i + "_default"));
                            } else {
                                user_settings[storage_key][i] = (v["default"]);
                            }
                        }
                    }
                });
                if (callback) { callback(user_settings); }
                return user_settings;
            }
        });
    }

    try {
        getSettings(storage_key, function (items) {
            let settings = items[storage_key];
            if (settings["enabled"] == true) {
                let tab = window.location;
                if (tab.href) {
                    if (tab.hostname == "www.roblox.com") {
                        async function injectCSS() {
                            // var amountOfSecondsBeforeLoop = (typeof (settings["loopSeconds"]) == "string" && Number(settings["loopSeconds"])) ? Number(settings["loopSeconds"]) : 100
                            console.log("Example Extension Right Here!");
                            // timeout(() => { injectCSS(settings) }, amountOfSecondsBeforeLoop)
                        }
                        injectCSS();
                    }
                }
            }
        });
    } catch (err) {
        console.log("Failed to add font settings to this tab.");
    }
})();