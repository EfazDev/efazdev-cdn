window.addEventListener("load", () => {
    var r = document.getElementById("old_green_color")
    r.addEventListener("click", () => {
        document.getElementById("color").value = "#56ac72"
    })
})