# Efaz's Roblox Verified Badge Add-on

Use this to troll some people to think you're verified on Roblox!
(WARNING: This will not show in-game or anyone elses side! Only yours and only affects on the Roblox website!)
(Another Note: I am not responsible if your account gets terminated if used! Use with caution and don't use for scamming!)
Instructions may depend on compatibility or operating systems. Go to https://www.efaz.dev/fake-roblox-verified-badge for more info.

In order to generate an approved user info JSON, you will need python. And simply add an item with the user id as the key and `{}` as the value. Example: <br>
`"1078332491": {},`

If you want to add a color to one user, add the key `hexColor` and value it to a hex value like `#ff0000` for red. Example: <br>
`"hexColor": "#ff0000",`